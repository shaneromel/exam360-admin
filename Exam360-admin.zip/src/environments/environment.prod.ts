/**
 * @license
 * Copyright Akveo. All Rights Reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 */
export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyBZ-APLqVu-ofiAxmMECBY42_AWd4LVLFE",
    authDomain: "exam360-2d6ff.firebaseapp.com",
    databaseURL: "https://exam360-2d6ff.firebaseio.com",
    projectId: "exam360-2d6ff",
    storageBucket: "exam360-2d6ff.appspot.com",
    messagingSenderId: "44211341037"
  }
};
