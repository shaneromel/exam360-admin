import { Component } from '@angular/core';

@Component({
  selector: 'ngx-team',
  styleUrls: ['./team.component.scss'],
  templateUrl: './team.component.html',
})
export class TeamComponent {
}
